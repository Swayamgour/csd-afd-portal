import { Link } from 'react-router-dom'
const a = [['user-manual', 'User Manual'], ['verify-supply-order', 'Verify Supply Order'], ['terms', 'Terms and conditions'], ['contact', 'Contact Us'], ['videos', 'Videos']]
const b = [['faq', 'FAQ'], ['help-desk', 'Help Desk'], ['eligibility', 'Eligibility Criteria'], ['payments', 'How to make online payments?']]
const L = ({ x }) => <ul>{x.map(([s, l]) => <li key={s}><Link to={`/info/${s}`}>{l}</Link></li>)}</ul>
export default function Footer() {
  return (
    <footer className="ftr">
      <div className="ftr-grid">
        <div><img src="/assets/logo.png" alt="National Informatics Centre" width="270" /><p>This site is designed, developed and hosted by National Informatics Centre</p></div>
        <nav aria-label="Footer" className="ftr-links"><L x={a} /><L x={b} /></nav>
        <section aria-labelledby="vig"><h2 id="vig">Be vigilant</h2>
          <p>Availing Services on CSD-AFD online Portal is absolutely free. In case, anyone asks for any money for registration/filling form on the portal or getting supply order released, it should be immediately reported to [Official Information To Be Provided]</p></section>
      </div>
      <p className="copy">Copyright © 2021 Canteen Stores Departments. All rights reserved. <Link to="/info/privacy">Privacy Policy</Link> | <Link to="/info/disclaimer">Disclaimer</Link>.</p>
    </footer>
  )
}
