import { Link } from "react-router-dom";
import { Heart, Star } from "lucide-react";
import { useStore } from "../context/Store.jsx";
export const Stars = ({ v, n }) => (
  <span
    className="rate"
    aria-label={`Rated ${v} out of 5${n ? `, ${n} reviews` : ""}`}
  >
    {[1, 2, 3, 4, 5].map((i) => (
      <Star key={i} size={13} fill="currentColor" aria-hidden />
    ))}
    {n != null && <small>({n.toLocaleString("en-IN")})</small>}
  </span>
);
export const Img = ({ p, ...r }) => (
  //  console.log(p) 
  < img src={p.image} alt={p.name} loading="lazy" {...r} />
);
export default function ProductCard({ p, deal }) {
  const { wish, cmp, toggleWish, toggleCmp, addCart } = useStore(),
    w = wish.includes(p.id),
    c = cmp.includes(p.id);
  return (
    <article className="card">
      <div className="card-img">
        <Link to={`/products/${p.id}`} aria-label={`View ${p.name}`}>
          <Img p={p} />
        </Link>
        {!deal && (
          <button
            className="fav"
            aria-pressed={w}
            aria-label={`${w ? "Remove" : "Add"} ${p.name} ${w ? "from" : "to"} wishlist`}
            onClick={() => toggleWish(p)}
          >
            <Heart size={16} fill={w ? "currentColor" : "none"} />
          </button>
        )}
      </div>
      <h3>
        <Link to={`/products/${p.id}`}>{p.name}</Link>
      </h3>
      <p className="price">
        <strong>
            ₹{p.price}
          {p.category === "car" && "*"}
        </strong>
        {p.mrp && (
          <>
            <s>
              <span className="sr"> </span>₹{p.mrp.toLocaleString("en-IN")}
            </s>
            <span className="off">{p.discount}% OFF</span>
          </>
        )}
        {/* <Stars v={p.rating} n={p.reviews} /> */}
      </p>
      {deal ? (
        <Link className="btn out wide" to={`/products/${p.id}`}>
          CHECK DEAL
        </Link>
      ) : (
        <div className="row">
          <button className="btn out" onClick={() => addCart(p)}>
            Add to Cart
          </button>
          <button
            className="btn out"
            aria-pressed={c}
            onClick={() => toggleCmp(p)}
          >
            {c ? "✓ Added" : "Compare"}
          </button>
        </div>
      )}
    </article>
  );
}
