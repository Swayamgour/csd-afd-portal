import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Search, ShoppingCart, Heart, User, Menu, X, ScanBarcode } from 'lucide-react'
import { useStore } from '../context/Store.jsx'
const nav = [['/', 'Home'], ['/info/about', 'About CSD'], ['/products?cat=car', 'Buy Car'], ['/products?cat=bike', 'Buy Bike'], ['/products?cat=white-goods', 'Other Products'], ['/info/buying-process', 'Buying Process'], ['/info/contact', 'Contact']]
export default function Header() {
  const [open, setOpen] = useState(false), [q, setQ] = useState('')
  const loc = useLocation(), go = useNavigate(), { cart, wish } = useStore()
  const submit = e => { e.preventDefault(); go(`/products?q=${encodeURIComponent(q.trim())}`); setOpen(false) }

  const location = useLocation()

  console.log('Current location:', location.pathname) // Log the current location


  return (
    <header className="hdr">
      <div className="hdr-top">
        <Link to="/" className="brand" aria-label="Canteen Stores Department - CSD AFD Online, home"><img src="https://afd.csdindia.gov.in/wp-content/themes/csdafdonline/assets/images/homepage/pics/2023/01/header.png" alt="Canteen Stores Department, Government of India, Ministry of Defence" /></Link>
        <form className="search" role="search" onSubmit={submit}>
          <label htmlFor="q" className="sr">Search products, brands or categories</label>
          <Search aria-hidden size={18} />
          <input id="q" value={q} onChange={e => setQ(e.target.value)} placeholder="Search" />
          {q && <button type="button" className="icon sm" aria-label="Clear search" onClick={() => setQ('')}><X size={16} /></button>}
        </form>
        {/* <span className="or" aria-hidden>OR</span> */}
        {/* <button className="scan" type="button" onClick={() => alert('Barcode scanning is not connected yet.')}>Scan Barcode <ScanBarcode size={18} aria-hidden /></button> */}
        <div className="actions">
          <Link to="/cart" className="icon" aria-label={`Cart, ${cart.length} items`}><ShoppingCart size={20} /><b>{cart.length || ''}</b></Link>
          <Link to="/products?wish=1" className="icon pink" aria-label={`Wishlist, ${wish.length} items`}><Heart size={20} fill="currentColor" /><b>{wish.length || ''}</b></Link>
          <Link to="/login" className="icon" aria-label="Login"><User size={20} fill="currentColor" /></Link>
        </div>
        <img className="forces" src="https://afd.csdindia.gov.in/wp-content/themes/csdafdonline/assets/images/homepage/pics/08/Army.png" alt="Indian Air Force, Navy, Army and Ministry of Defence emblems" />
        <img className="forces" src="https://afd.csdindia.gov.in/wp-content/themes/csdafdonline/assets/images/homepage/pics/2023/Indian-navy.png" alt="Indian Air Force, Navy, Army and Ministry of Defence emblems" />
        <img className="forces" src="https://afd.csdindia.gov.in/wp-content/themes/csdafdonline/assets/images/homepage/pics/2023/Air-force.png" alt="Indian Air Force, Navy, Army and Ministry of Defence emblems" />
        <img className="forces" src="https://afd.csdindia.gov.in/wp-content/themes/csdafdonline/assets/images/homepage/pics/08/indian-armed-forces.png" alt="Indian Air Force, Navy, Army and Ministry of Defence emblems" />
        <button className="icon menu" aria-expanded={open} aria-controls="mainnav" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {location.pathname !== "/login" && (
        <nav id="mainnav" aria-label="Main" className={open ? 'nav open' : 'nav'}>
          <ul>{nav.map(([to, l]) => <li key={l}><Link to={to} className={location.pathname + location.search === to ? 'active' : ''} aria-current={location.pathname + location.search === to ? 'page' : undefined} onClick={() => setOpen(false)}>{l}</Link></li>)}</ul>
        </nav>
      )}
    </header>
  )
}
