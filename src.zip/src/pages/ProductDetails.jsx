
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { RefreshCw, ShoppingCart, Copy } from "lucide-react";
import { Stars } from "../components/ProductCard.jsx";
import {
  Loader,
  EmptyState,
  ErrorState,
} from "../components/States.jsx";
import { fetchProduct } from "../data/api.js";
import { useStore } from "../context/Store.jsx";

const sw = {
  Red: "#c62828",
  Black: "#333",
  Silver: "#dcdcdc",
  Blue: "#2563eb",
  White: "#f5f5f5",
};

function Choice({
  label,
  options = [],
  value,
  set,
  swatch = false,
}) {
  if (!options.length) return null;

  return (
    <div className="choice" role="group" aria-label={label}>
      <p>
        {label} : <strong>{value}</strong>
      </p>

      <div className="row">
        {options.map((o) =>
          swatch ? (
            <button
              key={o}
              type="button"
              className="swatch"
              aria-pressed={o === value}
              aria-label={o}
              title={o}
              style={{
                background: sw[o] || "#999",
              }}
              onClick={() => set(o)}
            />
          ) : (
            <button
              key={o}
              type="button"
              className="chip"
              aria-pressed={o === value}
              onClick={() => set(o)}
            >
              {o}
            </button>
          ),
        )}
      </div>
    </div>
  );
}

export default function ProductDetails() {
  const { id } = useParams();

  const {
    addCart,
    toggleCmp,
    cmp,
  } = useStore();

  const [p, setP] = useState(undefined);
  const [err, setErr] = useState(false);

  const [color, setColor] = useState("");
  const [fuel, setFuel] = useState("");
  const [drive, setDrive] = useState("");

  const [main, setMain] = useState(0);

  const load = () => {
    setErr(false);
    setP(undefined);

    fetchProduct(id)
      .then((x) => {
        setP(x);
        setMain(0);

        if (x?.colors?.length) {
          setColor(x.colors[0]);
        }

        if (x?.fuel?.length) {
          setFuel(x.fuel[0]);
        }

        if (x?.trans) {
          setDrive(x.trans.split(" / ")[0]);
        }
      })
      .catch(() => setErr(true));
  };

  useEffect(() => {
    load();
  }, [id]);

  useEffect(() => {
    if (p) {
      document.title = `${p.name} - CSD AFD Online Portal`;
    }
  }, [p]);

  if (err) {
    return <ErrorState onRetry={load} />;
  }

  if (p === undefined) {
    return <Loader />;
  }

  if (!p) {
    return (
      <EmptyState
        title="Product not found"
        text="This product is not available."
        action={
          <Link className="btn" to="/products">
            Browse products
          </Link>
        }
      />
    );
  }

  /*
   * ============================================
   * STATIC PRODUCT IMAGES
   * ============================================
   */

  let imgs = [p.img];

  // -----------------------------
  // BIKE IMAGES
  // -----------------------------
  if (p.category === "bike") {
    imgs = [
      p.img,

      `/ img / ${p.id}/front.jpg`,
      `/img/${p.id}/rear.jpg`,
      `/img/${p.id}/left.jpg`,
      `/img/${p.id}/right.jpg`,
      `/img/${p.id}/side.jpg`,
    ];
  }

  // -----------------------------
  // THAR ROXX
  // -----------------------------
  if (p.id === "c5") {
    imgs = [
      p.img,
      "/img/c5-t0.jpg",
      "/img/c5-t1.jpg",
      "/img/c5-t2.jpg",
      "/img/c5-t3.jpg",
    ];
  }

  /*
   * ============================================
   * PRODUCT SPECS
   * ============================================
   */

  let specs = [];

  if (p.category === "car") {
    specs = [
      ["Engine", p.engine],
      ["Power", p.power],
      ["Mileage", p.mileage],
      ["Boot Space", p.boot],
      ["Airbags", p.airbags],
    ];
  } else if (p.category === "bike") {
    specs = [
      ["Type", p.type],
      ["Engine", p.engine],
      ["Power", p.power],
      ["Mileage", p.mileage],
      ["Brakes", p.brakes],
    ];
  } else {
    specs = [
      ["Type", p.type],
      [
        "MRP",
        p.mrp
          ? `₹${Number(p.mrp).toLocaleString("en-IN")}`
          : "-",
      ],
      [
        "Discount",
        p.discount != null ? `${p.discount}%` : "-",
      ],
    ];
  }

  return (
    <div className="wrap detail">

      {/* =========================================
          PRODUCT IMAGES
      ========================================= */}

      <div>
        <div className="main-image-wrapper">
          <img
            className="main-img"
            src={imgs[main]}
            alt={`${p.name} view ${main + 1}`}
          />
        </div>

        {imgs.length > 1 && (
          <ul
            className="thumbs"
            aria-label="Product images"
          >
            {imgs.map((src, i) => (
              <li key={src}>
                <button
                  type="button"
                  className={
                    main === i ? "active" : ""
                  }
                  aria-label={`Show image ${i + 1}`}
                  aria-pressed={main === i}
                  onClick={() => setMain(i)}
                >
                  <img
                    src={src}
                    alt={`${p.name} thumbnail ${i + 1}`}
                    loading="lazy"
                  />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* =========================================
          PRODUCT INFORMATION
      ========================================= */}

      <section
        className="panel"
        aria-labelledby="pn"
      >
        <h1 id="pn">{p.name}</h1>

        <p>
          <Stars v={p.rating} />

          <strong>{p.rating}</strong>{" "}

          <span className="muted small">
            (
            {p.reviews?.toLocaleString("en-IN") || 0}
            {" "}Reviews)
          </span>
        </p>

        <p className="big-price">
          {p.price}
        </p>

        {/* COLOR */}

        {p.colors?.length > 0 && (
          <Choice
            label="Color"
            options={p.colors}
            value={color}
            set={setColor}
            swatch
          />
        )}

        {/* FUEL */}

        {p.fuel?.length > 0 && (
          <Choice
            label="Fuel Type"
            options={p.fuel}
            value={fuel}
            set={setFuel}
          />
        )}

        {/* DRIVE - ONLY CAR */}

        {p.category === "car" &&
          p.trans && (
            <Choice
              label="Drive"
              options={p.trans.split(" / ")}
              value={drive}
              set={setDrive}
            />
          )}

        {/* =========================================
            SPECS
        ========================================= */}

        <dl className="specs">
          {specs.map(([key, value]) => (
            <div key={key}>
              <dt>{key} :</dt>
              <dd>{value || "-"}</dd>
            </div>
          ))}
        </dl>

        {/* =========================================
            ACTION BUTTONS
        ========================================= */}

        <div className="row3">

          <button
            className="btn out"
            type="button"
            onClick={() =>
              alert(
                "OEM link: [Official Information To Be Provided]",
              )
            }
          >
            VIEW ON OEM
          </button>

          <button
            className="btn out"
            type="button"
            aria-pressed={cmp.includes(p.id)}
            onClick={() => toggleCmp(p)}
          >
            <RefreshCw
              size={15}
              aria-hidden
            />

            {cmp.includes(p.id)
              ? "ADDED TO COMPARE"
              : "ADD TO COMPARE"}
          </button>

          <button
            className="btn"
            type="button"
            onClick={() => addCart(p)}
          >
            ADD TO CART

            <ShoppingCart
              size={16}
              aria-hidden
            />
          </button>

        </div>

        {/* =========================================
            SHARE / TEST RIDE
        ========================================= */}

        <div className="between share">

          <Link to="/info/book-test-ride">
            Book Test Ride
          </Link>

          <span>
            Share product:{" "}

            <button
              className="icon sm"
              type="button"
              aria-label="Copy link"
              onClick={() =>
                navigator.clipboard?.writeText(
                  window.location.href,
                )
              }
            >
              <Copy size={16} />
            </button>
          </span>

        </div>
      </section>
    </div>
  );
}

