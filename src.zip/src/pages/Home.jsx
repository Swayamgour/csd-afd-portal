import { Link } from "react-router-dom";
import { ArrowUpRight, ArrowRight, Headset, Info, ShieldAlert } from "lucide-react";
import ProductCard from "../components/ProductCard.jsx";
import { products, topDiscount } from "../data/products.js";
const cats = [
  ["Automobiles", "CAR", "/products?cat=car", "car", '/assets/maruti1.png'],
  ["Automobiles", "BIKE", "/products?cat=bike", "bike", '/assets/bullet1.png'],
  ["Home & Living", "APPLIANCE", "/products?cat=white-goods", "app", '/assets/white_goods1.png'],
];
const brands = [
  "SUZUKI",
  "SONY",
  "LG",
  "BAJAJ",
  "SAMSUNG",
  "PHILIPS",
  "BLUE STAR",
  "NISSAN",
  "TATA MOTORS",
  "ROYAL ENFIELD",
];

/* ---------- NEWS DATA (yahin se content edit karo) ---------- */
const featured = {
  to: "/products",
  tag: "Latest",
  title: "Browse the full range of cars, bikes and home appliances",
  text: "Compare models side by side and check price and availability before you order.",
};
const notices = [
  {
    to: "/info/buying-process",
    tag: "Guide",
    title: "How to buy: the step-by-step process",
    text: "From registration to supply order and delivery, see every step in one place.",
  },
  {
    to: "/info/verify-supply-order",
    tag: "Update",
    title: "Verify your supply order online",
    text: "Keep your supply order number ready to check its details and status.",
  },
  {
    to: "/info/payments",
    tag: "Guide",
    title: "How to make online payments",
    text: "Read the payment steps before you place your order to avoid delays.",
  },
  {
    to: "/info/contact",
    tag: "Advisory",
    alert: true,
    title: "Be vigilant: services on this portal are free",
    text: "If anyone asks for money for registration or supply order release, report it immediately.",
  },
];


export const Shop = ({ to = "/products", children = "Shop now" }) => (
  <Link to={to} className="shop">
    {children}
    <span>
      <ArrowUpRight size={18} aria-hidden />
    </span>
  </Link>
);
export default function Home() {
  const deals = ["w1", "c1", "w3", "w2", "w6"].map((id) =>
    products.find((p) => p.id === id),
  );
  return (
    <div className="wrap">
      {/* <section className="hero" aria-labelledby="h1">
        <h1 id="h1">
          CSD AFD
          <br />
          ONLINE
        </h1>
        <Shop to="/products?cat=car" />
        <p className="ticker" role="note">
          <strong>IMPORTANT:</strong> [Official notice to be provided]
        </p>
      </section> */}

      <section className="hero" aria-labelledby="h1">
        {/* Background Image Slider */}
        <div className="hero-slider">
          <img src="/assets/home_page.png" alt="" />
          <img src="/assets/home_page.png" alt="" />
          <img src="/assets/home_page.png" alt="" />
        </div>

        {/* Dark overlay */}
        <div className="hero-overlay"></div>

        {/* Content above slider */}
        <div className="hero-content">
          <h1 id="h1">
            CSD AFD
            <br />
            ONLINE
          </h1>

          <Shop to="/products?cat=car" />

          {/* <p className="ticker" role="note">
            <strong>IMPORTANT:</strong> [Official notice to be provided]
          </p> */}
        </div>
      </section>


      {/* category */}
      <section aria-labelledby="cats">
        <h2 id="cats">
          <span>CATEGORIES</span>
        </h2>
        <ul className="grid3 cats">
          {cats.map(([s, t, to, k, im], i) => (
            <li key={t} className={i === 2 ? "wide2" : ""}>
              <Link className={`cat ${k}`} to={to}>
                <small>{s}</small>
                <strong>{t}</strong>
                <span className="cta">Explore <ArrowUpRight size={15} aria-hidden /></span>
                <img src={im} alt="" loading="lazy" />
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* top discounts */}

      <section aria-labelledby="deals">
        <h2 id="deals">
          <span>TOP DISCOUNTS</span>
        </h2>
        <div className="grid5">
          {topDiscount?.map((p) => (
            <ProductCard key={p.id} p={p} deal />
          ))}
        </div>
      </section>


      <section aria-labelledby="brands">
        <h2 id="brands">
          <span>BRANDS</span>
        </h2>
        <ul className="brands">
          {brands.map((b) => (
            <li key={b}>{b}</li>
          ))}
        </ul>
      </section>

      {/* news */}
      <section aria-labelledby="news">
        <h2 id="news">
          <span>NEWS &amp; NOTICES</span>
        </h2>
        <div className="nw-grid">
          {/* Featured story */}
          <Link to={featured.to} className="nw-feature">
            <img src="/assets/news.jpg" alt="" loading="lazy" />
            <div className="nw-feature-body">
              <span className="nw-chip">{featured.tag}</span>
              <h3>{featured.title}</h3>
              <p>{featured.text}</p>
              <span className="nw-more">
                Read more <ArrowRight size={16} aria-hidden />
              </span>
            </div>
          </Link>

          {/* Notices list */}
          <ul className="nw-list">
            {notices.map((n) => (
              <li key={n.to} className={n.alert ? "alert" : ""}>
                <Link to={n.to}>
                  <span className={`nw-chip ${n.alert ? "alert" : ""}`}>
                    {n.alert && <ShieldAlert size={13} aria-hidden />}
                    {n.tag}
                  </span>
                  <strong>{n.title}</strong>
                  <span className="nw-text">{n.text}</span>
                </Link>
              </li>
            ))}
          </ul>

          {/* Info cards */}
          <div className="nw-cards">
            <article className="nw-card">
              <div className="nw-card-head">
                <span className="nw-ic" aria-hidden><Headset size={20} /></span>
                <h3>CS DTE &amp; SCPL Helpdesk</h3>
              </div>
              <p>
                Questions on registration, supply orders, payments or delivery? The
                helpdesk team can guide you.
              </p>
              <div className="row">
                <Link to="/info/help-desk" className="btn">Help Desk</Link>
                <Link to="/info/contact" className="btn out">Contact us</Link>
              </div>
            </article>

            <article className="nw-card note">
              <div className="nw-card-head">
                <span className="nw-ic" aria-hidden><Info size={20} /></span>
                <h3>Please Note</h3>
              </div>
              <ul className="nw-points">
                <li>Keep your supply order number and registered mobile number ready before contacting the helpdesk.</li>
                <li>Check price, availability and delivery details on the product page before ordering.</li>
                <li>Never share your password or OTP with anyone.</li>
              </ul>
            </article>

            {/* <article className="nw-card bene">
              <div className="nw-card-head">
                <span className="nw-ic" aria-hidden><BadgeCheck size={20} /></span>
                <h3>Important Information to all beneficiary</h3>
              </div>
              <ul className="nw-links">
                <li><Link to="/info/eligibility">Check eligibility criteria <ArrowRight size={15} aria-hidden /></Link></li>
                <li><Link to="/info/faq">Read frequently asked questions <ArrowRight size={15} aria-hidden /></Link></li>
                <li><Link to="/info/user-manual">View the user manual <ArrowRight size={15} aria-hidden /></Link></li>
              </ul>
            </article> */}
          </div>
        </div>
      </section>
    </div>
  );
}