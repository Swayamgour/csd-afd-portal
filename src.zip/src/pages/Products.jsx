import { useEffect, useMemo, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { SlidersHorizontal } from "lucide-react";
import ProductCard from "../components/ProductCard.jsx";
import { Shop } from "./Home.jsx";
import { Loader, EmptyState, ErrorState } from "../components/States.jsx";
import { fetchProducts } from "../data/api.js";
import { useStore } from "../context/Store.jsx";
const sorts = {
  rec: "Recommended",
  pa: "Price: Low to High",
  pd: "Price: High to Low",
  rt: "Rating",
};
const tg = (set) => (v) =>
  set((x) => (x.includes(v) ? x.filter((i) => i !== v) : [...x, v]));
const Group = ({ title, items, sel, set }) =>
  !items.length ? null : (
    <fieldset>
      <legend>{title}</legend>
      {items.map((b) => (
        <label key={b}>
          <input
            type="checkbox"
            checked={sel.includes(b)}
            onChange={() => tg(set)(b)}
          />{" "}
          {b}
        </label>
      ))}
    </fieldset>
  );
export default function Products() {
  const [sp, setSp] = useSearchParams(),
    { wish, cmp } = useStore();
  const [all, setAll] = useState(null),
    [err, setErr] = useState(false),
    [sort, setSort] = useState("rec"),
    [drawer, setDrawer] = useState(false);
  const [brands, setBrands] = useState([]),
    [types, setTypes] = useState([]),
    [fuels, setFuels] = useState([]),
    [pmax, setPmax] = useState(null);
  const cat = sp.get("cat") || "car",
    q = (sp.get("q") || "").toLowerCase(),
    onlyWish = sp.get("wish") === "1";
  const load = () => {
    setErr(false);
    setAll(null);
    fetchProducts()
      .then(setAll)
      .catch(() => setErr(true));
  };
  useEffect(load, []);
  const inCat = all ? all.filter((p) => p.category === cat) : [];
  const uniq = (f) => [...new Set(inCat.flatMap(f))];
  const hi = inCat.length ? Math.ceil(Math.max(...inCat.map((p) => p.lo))) : 0,
    lim = pmax ?? hi;
  const money = (v) =>
    cat === "car" ? `₹${v} Lakh` : `₹${Number(v).toLocaleString("en-IN")}`;
  const list = useMemo(() => {
    if (!all) return [];
    let l = all.filter(
      (p) =>
        (q || onlyWish || p.category === cat) &&
        (!onlyWish || wish.includes(p.id)) &&
        (!brands.length || brands.includes(p.brand)) &&
        (!types.length || types.includes(p.type)) &&
        (!fuels.length || (p.fuel || []).some((f) => fuels.includes(f))) &&
        (q || onlyWish || p.lo <= lim) &&
        (!q || `${p.name} ${p.brand} ${p.type}`.toLowerCase().includes(q)),
    );
    if (sort === "pa") l = [...l].sort((a, b) => a.lo - b.lo);
    if (sort === "pd") l = [...l].sort((a, b) => b.lo - a.lo);
    if (sort === "rt") l = [...l].sort((a, b) => b.rating - a.rating);
    return l;
  }, [all, cat, q, brands, types, fuels, lim, sort, onlyWish, wish]);
  const clear = () => {
    setBrands([]);
    setTypes([]);
    setFuels([]);
    setPmax(null);
  };
  const setCat = (c) => {
    setSp({ cat: c });
    clear();
  };
  const title = q
    ? `Results for “${sp.get("q")}”`
    : onlyWish
      ? "Wishlist"
      : { car: "Cars", bike: "Bikes", "white-goods": "Home appliances" }[cat];
  return (
    <div className="wrap layout">
      <button
        className="btn out filter-btn"
        aria-expanded={drawer}
        onClick={() => setDrawer(!drawer)}
      >
        <SlidersHorizontal size={16} aria-hidden /> Filters
      </button>
      <aside
        className={drawer ? "filters open" : "filters"}
        aria-label="Filters"
      >
        <div className="between">
          <h2>FILTERS</h2>
          <button className="link" onClick={clear}>
            clear all
          </button>
        </div>
        <fieldset className="plain">
          {[
            ["car", "Car"],
            ["bike", "Bike"],
            ["white-goods", "White Goods"],
          ].map(([v, l]) => (
            <label key={v}>
              <input
                type="radio"
                name="cat"
                checked={cat === v}
                onChange={() => setCat(v)}
              />{" "}
              {l}
            </label>
          ))}
        </fieldset>
        <Group
          title="CATEGORIES"
          items={uniq((p) => [p.type])}
          sel={types}
          set={setTypes}
        />
        <Group
          title="BRANDS"
          items={uniq((p) => [p.brand])}
          sel={brands}
          set={setBrands}
        />
        {cat === "car" && (
          <Group
            title="FUEL TYPE"
            items={uniq((p) => p.fuel || [])}
            sel={fuels}
            set={setFuels}
          />
        )}
        {hi > 0 && (
          <fieldset>
            <legend>PRICE</legend>
            <label htmlFor="pr" className="sr">
              Maximum price
            </label>
            <input
              id="pr"
              type="range"
              min="0"
              max={hi}
              step={cat === "car" ? 0.5 : 500}
              value={lim}
              onChange={(e) => setPmax(+e.target.value)}
            />
            <p className="muted small">Up to {money(lim)}</p>
          </fieldset>
        )}
      </aside>
      <section aria-labelledby="pt">
        <div className="banner">
          <div>
            <h2>
              {cat === "white-goods"
                ? "Home appliances"
                : cat === "bike"
                  ? "Bikes"
                  : "Cars"}
              <br />
              through CSD AFD
            </h2>
            <Shop to={`/products?cat=${cat}`} />
          </div>
          <img
            src={
              cat === "white-goods"
                ? "https://img.magnific.com/free-vector/household-appliances-realistic-composition_1284-65307.jpg"
                : cat === "bike"
                  ? "https://static.vecteezy.com/system/resources/thumbnails/049/532/221/small_2x/stylish-motorcycle-in-dramatic-lighting-against-a-dark-background-showcasing-its-sleek-design-and-vintage-charm-photo.jpeg"
                  : "https://img.sm360.ca/images//page/dilawri-group-of-companies/138931/file/contentpage_banner_1920x480_revuelto1686931070410.png"
            }
            alt={
              cat === "white-goods"
                ? "Home appliances"
                : cat === "bike"
                  ? "Bikes"
                  : "Cars"
            }
          />
        </div>
        <div className="between bar">
          <h1 id="pt">{title}</h1>
          <label className="sort">
            Sort by :{" "}
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              {Object.entries(sorts).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </label>
        </div>
        <p className="muted" aria-live="polite">
          {all && `${list.length} products`}
          {cmp.length > 0 && (
            <>
              {" "}
              · <Link to="/compare">Compare {cmp.length} selected</Link>
            </>
          )}
        </p>
        {err ? (
          <ErrorState onRetry={load} />
        ) : !all ? (
          <Loader label="Loading products" />
        ) : !list.length ? (
          <EmptyState
            title="No products found"
            text="Try changing the filters or search with different words."
          />
        ) : (
          <div className="grid4">
            {list.map((p) => (
              <ProductCard key={p.id} p={p} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
