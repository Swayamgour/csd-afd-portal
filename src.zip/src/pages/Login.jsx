import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ShieldCheck, ArrowLeft } from "lucide-react";
// MOCK flow. No credentials/tokens stored in browser. Wire to a real auth API + server-verified CAPTCHA.
export default function Login() {
  const [step, setStep] = useState(1),
    [email, setEmail] = useState(""),
    [pw, setPw] = useState(""),
    [errs, setErrs] = useState({}),
    [otp, setOtp] = useState(Array(6).fill(""));
  const refs = useRef([]),
    go = useNavigate();
  const send = (e) => {
    e.preventDefault();
    const x = {};
    if (!/^\S+@\S+\.\S+$/.test(email)) x.email = "Enter a valid email address.";
    if (pw.length < 6) x.pw = "Enter your password (at least 6 characters).";
    setErrs(x);
    if (!Object.keys(x).length) setStep(2);
  };
  const ch = (i, v) => {
    if (!/^\d?$/.test(v)) return;
    const n = [...otp];
    n[i] = v;
    setOtp(n);
    if (v && i < 5) refs.current[i + 1].focus();
  };
  const verify = (e) => {
    e.preventDefault();
    if (otp.join("").length < 6) return setErrs({ otp: "Enter all 6 digits." });
    go("/");
  };
  return (
    <div className="wrap login">
      <img
        className="login-art"
        src="/assets/login.png"
        alt="Armed forces personnel from the Army, Navy and Air Force"
      />
      <div className="panel logincard" aria-labelledby="lh">
        <div className="between">
          <Link to="/info/login-instructions" className="vli">
            View Login Instructions
          </Link>
          <button
            className="circle"
            aria-label="Go back"
            onClick={() => (step === 2 ? setStep(1) : go(-1))}
          >
            <ArrowLeft />
          </button>
        </div>
        {step === 1 ? (
          <form onSubmit={send} noValidate>
            <h1 id="lh">Welcome Back!</h1>
            <p className="muted">log in your account</p>
            <label htmlFor="em">
              Email <span aria-hidden>*</span>
            </label>
            <input
              id="em"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              aria-invalid={!!errs.email}
              aria-describedby="em-e"
            />
            <p
              id="em-e"
              className="err"
              role={errs.email ? "alert" : undefined}
            >
              {errs.email && `⚠ ${errs.email}`}
            </p>
            <label htmlFor="pw">
              Password <span aria-hidden>*</span>
            </label>
            <input
              id="pw"
              type="password"
              autoComplete="current-password"
              required
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              aria-invalid={!!errs.pw}
              aria-describedby="pw-e"
            />
            <p id="pw-e" className="err" role={errs.pw ? "alert" : undefined}>
              {errs.pw && `⚠ ${errs.pw}`}
            </p>
            <div className="between small">
              <label className="inline">
                <input type="checkbox" /> Remember Me
              </label>
              <Link to="/info/forgot-password">Forgot Password?</Link>
            </div>
            <p className="captcha">
              [CAPTCHA placeholder - integrate a verified provider]
            </p>
            <button className="btn wide" type="submit">
              Send 6-digit code
            </button>
            <p className="orline">
              <span>or</span>
            </p>
            <button
              className="btn out wide"
              type="button"
              onClick={() => alert("Biometric login is not connected yet.")}
            >
              Login using Biometrics
            </button>
          </form>
        ) : (
          <form onSubmit={verify} noValidate>
            <h1 id="lh">Enter OTP</h1>
            <p className="muted">you received on your registered email</p>
            <span className="shield">
              <ShieldCheck size={44} aria-hidden />
            </span>
            <fieldset className="otp">
              <legend className="sr">6-digit code</legend>
              {otp.map((d, i) => (
                <input
                  key={i}
                  ref={(el) => (refs.current[i] = el)}
                  inputMode="numeric"
                  maxLength={1}
                  value={d}
                  aria-label={`Digit ${i + 1}`}
                  onChange={(e) => ch(i, e.target.value)}
                  onKeyDown={(e) =>
                    e.key === "Backspace" &&
                    !d &&
                    i > 0 &&
                    refs.current[i - 1].focus()
                  }
                />
              ))}
            </fieldset>
            <p className="err" role={errs.otp ? "alert" : undefined}>
              {errs.otp && `⚠ ${errs.otp}`}
            </p>
            <p className="small">
              Didn’t receive OTP ?{" "}
              <button
                type="button"
                className="link"
                onClick={() => setOtp(Array(6).fill(""))}
              >
                Send Again
              </button>
            </p>
            <button className="btn wide" type="submit">
              Verify
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
