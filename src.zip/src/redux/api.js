import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const BASE_URL = "http://localhost:5000/api";

export const api = createApi({
    reducerPath: "api",

    baseQuery: fetchBaseQuery({
        baseUrl: BASE_URL,

        prepareHeaders: (headers) => {
            const token = localStorage.getItem("accessToken");

            if (token) {
                headers.set("Authorization", `Bearer ${token}`);
            }

            headers.set("Content-Type", "application/json");

            return headers;
        },
    }),

    tagTypes: [
        "Auth",
        "Beneficiary",
        "Product",
        "Category",
        "Brand",
        "Demand",
        "Order",
        "Notification",
    ],

    endpoints: () => ({}),
});